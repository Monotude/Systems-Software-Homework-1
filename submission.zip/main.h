#ifndef _MAIN_H
#define _MAIN_H
#include "bof.h"

extern BOFFILE file;
extern BOFHeader header;
extern int tracing;

#endif