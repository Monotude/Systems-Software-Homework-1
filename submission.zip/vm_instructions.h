#ifndef _VM_INSTRUCTIONS_H
#define _VM_INSTRUCTIONS_H
#include "instruction.h"

extern void executeInstruction(bin_instr_t instruction);

#endif